# Sign-Language-Recognition
-It is a Sign language to text conversion project using Machine Learning.
- A web app interface captures the hand image from webcam feed and then predicts its output from backend trained machine learning model and displays it on the screen.
- The web page has also some more pages like sign to text, text to sign, dataset, mediapipe demonstration, about, information, etc. which contains the corresponding information.


![image](https://user-images.githubusercontent.com/67855452/169707625-894a5c43-b954-4938-9a98-b267af30e676.png)
![image](https://user-images.githubusercontent.com/67855452/169707640-e4118a77-3214-4243-ac6b-e32cd87e5672.png)


https://user-images.githubusercontent.com/67855452/169708313-b9c9e214-814f-421a-8c46-f32a1c7cbcdf.MP4

